#! /usr/bin/env python3
# coding=utf-8

"""
< For Rex Debug >
"""

from django.shortcuts import render,render_to_response
from django.http import HttpResponse,HttpResponseRedirect

import json,time,threading,copy
from pprint import pprint as pp

from . import vcore

class SubProvider(vcore.Provider):

    @property
    def formatted_rawdata(self):
        from .test_cookies_of_rex import random_gen_cookies
        pp(random_gen_cookies())
        #assert False
        return random_gen_cookies()


class SubExtractor(vcore.Extractor):

    @property
    def UI_data(self):

        UIout = []


        for d in self._get_data():
            tmp_out = {}

            ERD_ID = d
            others = self.output_data[d]

            if not others['excel']: continue

            versions = list(others['excel'].keys())
            lastest_ver = max(versions)

            print("UI lastest version : <{}> for ERD : [{}]".format(lastest_ver, ERD_ID))

            deep_excel = others['excel'][lastest_ver]
            deep_jira  = others['jira'][lastest_ver]

            # excel part : ERD table partition
            tmp_out['erd_id'] = deep_excel['erd_id']
            tmp_out['author'] = deep_excel['author']
            tmp_out['category'] = deep_excel['category']
            tmp_out['product_priority'] = deep_excel['product_priority']
            tmp_out['description'] = deep_excel['description']
            tmp_out['title'] = deep_excel['title']
            tmp_out['version'] = ','.join(versions)

            # jira part : ERD table partition
            tmp_out['HLD'] = deep_jira['HLD']
            tmp_out['l1_jira'] = deep_jira['l1_jira']
            tmp_out['l2_jira'] = deep_jira['l2_jira']
            tmp_out['platform'] = deep_jira['platform']
            tmp_out['status'] = deep_jira['status']
            tmp_out['workload'] = deep_jira['workload']
            if deep_jira['bug_jiras']:
                tmp_out['bug_jiras'] = deep_jira['bug_jiras'].split(',')
            else:
                tmp_out['bug_jiras'] = []

            # jira part : TestCases table partition
            # Now Maybe 'case_age' NOT display
            tmp_out['case_name'] = list(deep_jira['F_casetree'].keys())
            tmp_out['F_report_path'] = []
            for dj in deep_jira['F_casetree']:
                tmp_out['F_report_path'].append(deep_jira['F_casetree'][dj]['F_report_path'])

            UIout.append(tmp_out)
        pp(UIout)
        return UIout

def rex_jump(request):

    ext = SubExtractor(erd_id_list = [
        "04.60.25",
        "04.60.26",
        "04.60.27",
        "04.60.28",
        "04.60.29",
        "04.60.30",
        "04.60.31",
        "04.60.32",
        "04.60.33",
        "04.60.34",
        "04.60.35",
        "04.60.36",
        "04.60.37",
        "04.60.38",
        "04.60.39",
        "04.60.40",
        "04.60.41",
        "04.60.42",
        "04.60.43",
        "04.60.44",
    ], extract_types = ["excel", 'jira'])

    #vcore.splitter('save', provider = SubProvider())

    vcore.splitter('pick', extractor = ext)
    #pp(ext.output_data)

    # pp(ext.UI_data)

    return render(request, 'LigerUI/ACIS/rex_test_page.htm', {'cookies' : json.dumps(ext.UI_data)})
