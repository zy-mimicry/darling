"""AcisWeb URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include

from . import (views,
               views_of_rex,
               views_of_shw,
               views_of_FT)

app_name = 'AcisDB'

urlpatterns = [
    path('', views.index, name = 'index'),

    path('9X28_default_index/', views_of_rex.ERD_9X28_index, name = "ERD_9X28_index"),
    path('9X40_default_index/', views_of_rex.ERD_9X40_index, name = "ERD_9X40_index"),
    path('SD55_default_index/', views_of_rex.ERD_SD55_index, name = "ERD_SD55_index"),

    path('columns_data_select/', views_of_rex.columns_data_select, name = 'columns_data_select'),

    path('commands/', views_of_rex.commands, name = "commands"),
    path('help/',     views_of_rex.help,     name = "help"),
    path('about/',    views_of_rex.about,    name = "about"),

    path('query/',    views_of_rex.query,    name = "query"),
    path('query/switch/',    views_of_rex.query_switch,  name = "switch"),

    path('actions/', views_of_rex.actions_dispatcher,   name = "actions"),

    # >Debug Page<
    path('rex_test/', views_of_rex.rex_jump, name = 'rex_test'),
    path('shw_test/', views_of_shw.shw_jump, name = 'shw_test'),
]
