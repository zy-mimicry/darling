#! /usr/bin/env python3
# coding=utf-8

"""
< For Rex Debug >
"""

from django.shortcuts import render,render_to_response
from django.http import HttpResponse,HttpResponseRedirect
from pprint import pprint as pp
import json


FT_TABLE = {
    'ERD_ID' : '',
    'L1_Ticket' : '',
    'L2_Ticket' : '',
    'JIRA_BUG_Tickets' : {},
    'TestCases' : {},
    'TestReports' : {},
    'Description' : '',
    'Version' : '',
    'HLD' : '',
    'Age' : '',
    'Action' : '',
    'Status' : '',
    'LastModifier' : '',
    'History' : '',
    'Platform' : '',
}

# from .test_cookies_of_rex import random_gen_cookies


def rex_jump(request):

    FT_TABLE['ERD_ID'] = '100'
    FT_TABLE['L1_Ticket'] = 'QTI9X28-5555'
    FT_TABLE['L2_Ticket'] = 'QTI9X28-6666'
    FT_TABLE['JIRA_BUG_Tickets'] = {'first' :'QTI9X28-1234', 'second' : 'QTI9X28-5655'}
    FT_TABLE['TestCases'] = {'first' : 'ACIS_FIRST_TEST_CASE', 'second' : "ACIS_SECOND_TEST_CASE"}
    FT_TABLE['TestReports'] = {'first' : 'ACIS_FIRST_TEST_CASE_REPORT', 'second' : "ACIS_SECOND_TEST_CASE_REPORT"}
    FT_TABLE['Description'] = 'Description Link'
    FT_TABLE['Version'] = '2.0.1'
    FT_TABLE['HLD'] = 'HLD Link here'
    FT_TABLE['Age'] = '2018-12-19'
    FT_TABLE['Action'] = 'new'
    FT_TABLE['Status'] = 'undo'
    FT_TABLE['LastModifier'] = 'Rex Zheng'
    FT_TABLE['History'] = '2.0.100'
    FT_TABLE['Platform'] = 'SD55'

    # splitter('save', Provider())

    ext = Extractor(erd_id_list = [
        "04.60.25",
        "04.60.26",
        "04.60.27",
        "04.60.28",
        "04.60.29",
        "04.60.30",
    ], extract_types = ["excel", 'jira'])

    splitter('pick', extractor = ext)

    pp(ext.output_data)

    return render(request, 'LigerUI/ACIS/rex_test_page.htm', {'cookies' : json.dumps([FT_TABLE])})

class Provider:
    def __init__(self):
        pass

    @property
    def formatted_rawdata(self):
        from .test_cookies_of_rex import random_gen_cookies
        return random_gen_cookies()

class Extractor:
    def __init__(self, erd_id_list, extract_types):

        self.data_carrier = {}
        self.erd_list = erd_id_list
        self.ext_type = extract_types

    @property
    def ERD_ID_list(self):
        return self.erd_list

    @property
    def extract_types(self):
        return self.ext_type

    @property
    def output_data(self):
        return self.data_carrier

    def UI_data(self):
        self.data_carrier

        UIout = []

        for i in self.data_carrier:
            m = dict(
                erd_id = i,
                category = self.data_carrier[i]['excel']['category'],
                title = self.data_carrier[i]['excel']['title'],
                description = self.data_carrier[i]['excel']['description'],
                product_priority = self.data_carrier[i]['excel']['product_priority'],
                author = self.data_carrier[i]['excel']['author'],
                HLD = self.data_carrier[i]['jira']['HLD'],
                l1_jira = self.data_carrier[i]['jira']['l1_jira'],
                l2_jira = self.data_carrier[i]['jira']['l2_jira'],
                bug_jiras = self.data_carrier[i]['jira']['bug_jiras'], # should be modified
                status = self.data_carrier[i]['jira']['status'],
                platform = self.data_carrier[i]['jira']['platform'],
                workload = self.data_carrier[i]['jira']['workload'],

                version = self.data_carrier[i]['excel']['version'],

                # case_names = 
                # F_report_paths = 
            )



def splitter(action, provider = None, extractor = None):
    """
    action: 'save', 'pick'

    callback: get_cookies > provide cookies
    get_cookies return:  [{'ERD_ID'  : "",'excel' : {}, 'jira' : {}, 'jenkins' : {}, 'UIform' : {}}, ...]

    pick_erd_list: {'erd_list' : [], 'types' : [] }

    Support Types:
    1. Data from/to Excel
    2. Data from/to JIRA Ticket
    3. Data from/to Jenkins
    4. Data from/to UI Form

    NOTE: 'excel' type should be processed firstly!!!

    """
    types = {'excel'    : ExcelDataProcesser,
             'jira'     : JiraDataProcesser,
             'jenkins'  : JenkinsDataProcesser,
             'UIform'   : UiFormDataProcesser}

    #print(provider.formatted_rawdata)
    #assert False

    if action == 'save':
        if not provider:
            print("[provider] does NOT exist."); return
        for cookie in provider.formatted_rawdata:
            ERD_ID = cookie.pop('ERD_ID')
            for tp in cookie:
                if tp in types and cookie[tp]:
                    # print("rex >>> ERD_ID : {}, tp : {} ".format(ERD_ID, tp))
                    # assert False
                    types[tp](ERD_ID, cookies = cookie[tp]).doit(action)

    elif action == 'pick':
        #if not pick_erd_list['erd_list']:
        if not extractor:
            print("[extractor] does NOT exist.");return
        # out_data > eg. {'ERD_ID' : {'excel' : data, 'jira': data, 'jenkins' : data, 'UIform' : data}}
        out_data = {}
        for ERD_ID in extractor.ERD_ID_list:
            extractor.output_data[ERD_ID] = {}
            for tp in extractor.extract_types:
                if tp in types:
                    extractor.output_data[ERD_ID][tp] = types[tp](ERD_ID).doit(action)
        return extractor.output_data
    else:
        print("Action NOT support.")

# def splitter(action, provider = None, extractor = None):
# #def splitter(action, get_cookies = None, pick_erd_list = {'erd_list' : [], 'types' : []}):
#     """
#     action: 'save', 'pick'

#     callback: get_cookies > provide cookies
#     get_cookies return:  [{'ERD_ID'  : "",'excel' : {}, 'jira' : {}, 'jenkins' : {}, 'UIform' : {}}, ...]

#     pick_erd_list: {'erd_list' : [], 'types' : [] }

#     Support Types:
#     1. Data from/to Excel
#     2. Data from/to JIRA Ticket
#     3. Data from/to Jenkins
#     4. Data from/to UI Form

#     NOTE: 'excel' type should be processed firstly!!!

#     """
#     types = {'excel'    : ExcelDataProcesser,
#              'jira'     : JiraDataProcesser,
#              'jenkins'  : JenkinsDataProcesser,
#              'UIform'   : UiFormDataProcesser}

#     if action == 'save':
#         if not get_cookies:
#             print("[get_cookies] callback function is NOT supported.")
#             return
#         for cookie in get_cookies():
#             ERD_ID = cookie.pop('ERD_ID')
#             for tp in cookie:
#                 if tp in types and cookie[tp]:
#                     types[tp](ERD_ID, cookies = cookie[tp]).doit(action)

#     elif action == 'pick':
#         if not pick_erd_list['erd_list']:
#             print("[pick_erd_list['erd_list']] is empty]")
#             return
#         # out_data > eg. {'ERD_ID' : {'excel' : data, 'jira': data, 'jenkins' : data, 'UIform' : data}}
#         out_data = {}
#         for ERD_ID in pick_erd_list['erd_list']:
#             out_data[ERD_ID] = {}
#             for tp in pick_erd_list['types']:
#                 if tp in types:
#                     out_data[ERD_ID][tp] = types[tp](ERD_ID).doit(action)
#         return out_data
#     else:
#         print("Action NOT support.")


class CookiesProcesser:

    def save(self):
        assert False, "Children Should implement this method."

    def pick(self):
        assert False, "Children Should implement this method."

    def doit(self):
        assert False, "Children Should implement this method."

    # Extend Common methods
    def get_lastest_ver(self, objs):

        versions = []
        maps = {}

        if not objs: return None

        for o in objs:
            maps[o] = o.version
            versions.append(o.version)

        lastest = max(versions)
        for m in maps:
            if m.version == lastest:
                return m

dynamic_conf_category = {
    'excel' : (
        'erd_id',
        'category',
        'title',
        'description',
        'product_priority',
        'author',
        'version'),

    'jira' : (
        'HLD',
        'status',
        'l1_jira',
        'l2_jira',
        'bug_jiras',
        'platform',
        'workload',

        'F_casetree',
        # F_casetree >> {
        # {
        # 'case_name' : "",
        # 'case_age' : "",
        # 'F_report_path': "",
        # },
        # ... }
    ),

    'jenkins' : (
        'IR_casetree',
        # IR_casetree >> {
        # 'casename' : {
        #    'IR_report_path': "",
        #    'fw_version': "",
        #    'test_result' : "",
        #    'test_log' : "",
        #    'test_date' : "",
        # },
        # 'casename2' : {},
        # ... }
    ),

    'UIform' :(
        'UItest',
    ),
}

from .models_of_rex import Erds,TestCases,TestReports

class ExcelDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['excel']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        """
        auto ignore the data outof 'data_category'.
        """

        except_list = []

        if not self.cookies:
            print("cookies is empty, do nothing.");return

        for c in self.cookies:
            if c not in ExcelDataProcesser.data_category:
                except_list.append(c)

        for e in except_list:
            self.cookies.pop(e)

        e = Erds(**self.cookies)
        e.save()

    def pick(self):
        """
        """

        el = Erds.objects.filter(erd_id = self.ERD_ID)
        if not el:
            print("The item about your ERD_ID, doesn't exist.")
            return {}

        out = {}
        for e in el:
            out[e.version] = {}
            for d in ExcelDataProcesser.data_category:
                out[e.version][d] = e.__dict__[d]
        # print("excel output : {}".format(out))
        return out


    def doit(self,action):
        if action == 'save':
            self.save()
        elif action == 'pick':
            return self.pick()

class JiraDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['jira']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model


    def save(self):
        '''
        auto ignore the data outof 'data_category'.
        '''

        except_list = []

        if not self.cookies:
            print("cookies is empty, do nothing.");return

        for c in self.cookies:
            if c not in JiraDataProcesser.data_category:
                except_list.append(c)

        for e in except_list:
            self.cookies.pop(e)

        el = Erds.objects.filter(erd_id = self.ERD_ID)

        e = self.get_lastest_ver(el)
        #print("rex >> ERD : {} , el {}".format(self.ERD_ID, el))
        if not e :
            print("ERD_ID does NOT exist, save action error.")
            return

        # Erds Table items save.
        for d in JiraDataProcesser.data_category:
            for c in self.cookies:
                if d in Erds.__dict__ and d == c:
                    e.__dict__[d] = self.cookies[c]
        e.save()

        # TestCases Table items save.
        casetree = []
        if 'F_casetree' in  self.cookies and self.cookies['F_casetree']:
            casetree = self.cookies['F_casetree']

            if not e.testcases_set.all():
                for ct in casetree:
                    e.testcases_set.create(**ct).save()
            else:
                tcl = e.testcases_set.all()

                for ct in casetree:
                    if ct['case_name'] not in [tc.case_name for tc in tcl]:
                        e.testcases_set.create(**ct).save()
                    else:

                        #print("rex >> F_report_path : {}".format(ct['F_report_path']))
                        s1 = set(ct['F_report_path'].split(','))
                        #print("rex >> sl : {}".format(s1))
                        #assert False
                        tc = e.testcases_set.get(case_name = ct['case_name'])

                        if tc and s1 - set(tc.F_report_path.split(',')):
                            print("rex here set --: ", s1 -set(tc.F_report_path.split(',')))
                            for s in (s1 -set(tc.F_report_path.split(','))):
                                tc.F_report_path += str(s)
                                tc.save()
                        else:
                            pass # do nothing.
        else:
            print("F_case_tree error.")

    def pick(self):

        el = Erds.objects.filter(erd_id = self.ERD_ID)
        out = {}

        if not el: return out

        for e in el:
            out[e.version] = {}

            for d in JiraDataProcesser.data_category:
                # pick Erds Table items
                if d in Erds.__dict__:
                    out[e.version][d] = e.__dict__[d]
                # pick TestCases Table items
                if d == 'F_casetree':
                    out[e.version]['F_casetree'] = {}
                    tcl = e.testcases_set.all()
                    for tc in tcl:
                        out[e.version]['F_casetree']['case_name'] = tc.case_name
                        out[e.version]['F_casetree']['case_age']  = tc.case_age
                        out[e.version]['F_casetree']['F_report_path'] = tc.F_report_path
        return out

    def doit(self,action):
        if action == 'save':
            self.save()
        elif action == 'pick':
            return self.pick()

class JenkinsDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['jenkins']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        '''
        auto ignore the data outof 'data_category'.
        '''
        except_list = []

        if not self.cookies:
            print("cookies is empty, do nothing.");return

        for c in self.cookies:
            if c not in JenkinsDataProcesser.data_category:
                except_list.append(c)

        for e in except_list:
            self.cookies.pop(e)

        e = Erds(**self.cookies)

    def pick(self):
        pass

    def doit(self,action):
        if action == 'save':
            self.save()
        elif action == 'pick':
            return self.pick()

class UiFormDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['UIform']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        pass

    def pick(self):
        pass

    def doit(self,action):
        if action == 'save':
            self.save()
        elif action == 'pick':
            return self.pick()


