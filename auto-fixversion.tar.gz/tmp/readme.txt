README
======


0. fixVersion可能不存在，脚本不能正常运行，请手动在JIRA上添加FixVersions
1. 请修改login.ini文件，换成用户的username和password
2. 请修改cookies.ini文件，添加fixversion列表和Tickets列表(NOTE:列表的最后不要以','结尾)
3. 配置python环境:
 - pip3 install jira
 - pip3 install ipython

4. 执行命令:
 - python3 ./auto_jira.py
