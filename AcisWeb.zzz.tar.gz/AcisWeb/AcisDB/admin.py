from django.contrib import admin
from .models_of_rex import Erds, TestReports

# Register your models here.
admin.site.register(Erds)
admin.site.register(TestReports)