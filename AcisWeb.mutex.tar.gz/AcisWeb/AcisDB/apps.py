from django.apps import AppConfig


class AcisdbConfig(AppConfig):
    name = 'AcisDB'
