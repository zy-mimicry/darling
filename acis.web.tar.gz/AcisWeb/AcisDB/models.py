from django.db import models

# Create your models here.

from . import models_of_rex