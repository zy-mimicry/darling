from django.contrib import admin

# Register your models here.

from . import models_of_rex
