#! /usr/bin/env python3
# coding=utf-8

import jira 
import configparser

def login_jira(auth_file):
    conf = configparser.ConfigParser()
    conf.read(auth_file)
    kvs= conf.items("auth")

    server   = "https://issues.sierrawireless.com/"
    username = ""
    passwd   = ""
    for k in kvs:
        if k[0] == 'username':
            username = k[1].split("'")[1]
        if k[0] == 'passwd':
            passwd = k[1].split("'")[1]
    #print("items:\n\tusername:{}\n\tpasswd:{}".format(username,passwd))
    handle  = jira.JIRA(server = "https://issues.sierrawireless.com/", basic_auth=(username, passwd))
    return handle

def get_tickets_and_versions(file_name):

	conf = configparser.ConfigParser()
	conf.read(file_name)

	fixVersion = conf.items('fixVersion')[0]

	version_list = [ i.strip() for i in fixVersion[1].split(',')]
	print(version_list)

	tickets  = conf.items('Tickets')[0]

	ticket_list = [ i.strip() for i in tickets[1].split(',')]
	print(ticket_list)

	return {'version_list' : version_list,
		'ticket_list'  : ticket_list}


def issue_generater(jira, ticket_list):
    issues = []
    for tl in ticket_list:
        issues.append(jira.issue(tl))
    return issues

def fill_fix_version(issues, versions):

    fixVersions = []

    print("new add fixVersions:")
    for v in versions:
        fixVersions.append({'name' : v})
        print("\t - {}".format(v))

    for issue in issues:
        for ver in issue.fields.fixVersions:
            if ver.name not in fixVersions:
                fixVersions.append({'name' : ver.name})

    for issue in issues:
        try:
            issue.update(fields = {'fixVersions' : fixVersions})
        except Exception as e:
            print("issue update fixVersion errror -- [{}] [{}]".format(issue, fixVersions))
            continue

if __name__ == "__main__":
	mjira = login_jira(auth_file = './login.ini')
	items = get_tickets_and_versions('./cookies.ini')
	issues = issue_generater(mjira, items['ticket_list'])
	fill_fix_version(issues, items['version_list'])

