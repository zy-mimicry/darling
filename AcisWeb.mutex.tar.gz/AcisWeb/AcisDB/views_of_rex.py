#! /usr/bin/env python3
# coding=utf-8

"""
< For Rex Debug >
"""

from django.shortcuts import render,render_to_response
from django.http import HttpResponse,HttpResponseRedirect
from pprint import pprint as pp
import threading
import json,time

mutex = threading.Lock()

# FT_TABLE = {
#     'ERD_ID' : '',
#     'L1_Ticket' : '',
#     'L2_Ticket' : '',
#     'JIRA_BUG_Tickets' : {},
#     'TestCases' : {},
#     'TestReports' : {},
#     'Description' : '',
#     'Version' : '',
#     'HLD' : '',
#     'Age' : '',
#     'Action' : '',
#     'Status' : '',
#     'LastModifier' : '',
#     'History' : '',
#     'Platform' : '',
# }

# from .test_cookies_of_rex import random_gen_cookies


def rex_jump(request):

    # FT_TABLE['ERD_ID'] = '100'
    # FT_TABLE['L1_Ticket'] = 'QTI9X28-5555'
    # FT_TABLE['L2_Ticket'] = 'QTI9X28-6666'
    # FT_TABLE['JIRA_BUG_Tickets'] = {'first' :'QTI9X28-1234', 'second' : 'QTI9X28-5655'}
    # FT_TABLE['TestCases'] = {'first' : 'ACIS_FIRST_TEST_CASE', 'second' : "ACIS_SECOND_TEST_CASE"}
    # FT_TABLE['TestReports'] = {'first' : 'ACIS_FIRST_TEST_CASE_REPORT', 'second' : "ACIS_SECOND_TEST_CASE_REPORT"}
    # FT_TABLE['Description'] = 'Description Link'
    # FT_TABLE['Version'] = '2.0.1'
    # FT_TABLE['HLD'] = 'HLD Link here'
    # FT_TABLE['Age'] = '2018-12-19'
    # FT_TABLE['Action'] = 'new'
    # FT_TABLE['Status'] = 'undo'
    # FT_TABLE['LastModifier'] = 'Rex Zheng'
    # FT_TABLE['History'] = '2.0.100'
    # FT_TABLE['Platform'] = 'SD55'
    # return render(request, 'LigerUI/ACIS/rex_test_page.htm', {'cookies' : json.dumps([FT_TABLE])})

    splitter('save', Provider())
    #assert False , "save"

    ext = Extractor(erd_id_list = [
        "04.60.25",
        "04.60.26",
        "04.60.27",
        "04.60.28",
        "04.60.29",
        "04.60.30",
        "04.60.31",
        "04.60.32",
        "04.60.33",
        "04.60.34",
        "04.60.35",
        "04.60.36",
        "04.60.37",
        "04.60.38",
        "04.60.39",
        "04.60.40",
        "04.60.41",
        "04.60.42",
        "04.60.43",
        "04.60.44",
    ], extract_types = ["excel", 'jira'])

    splitter('pick', extractor = ext)
    #pp(ext.output_data)

    # pp(ext.UI_data)

    return render(request, 'LigerUI/ACIS/rex_test_page.htm', {'cookies' : json.dumps(ext.UI_data)})

class Provider:
    def __init__(self):
        pass

    @property
    def formatted_rawdata(self):
        from .test_cookies_of_rex import random_gen_cookies
        return random_gen_cookies()

class Extractor:
    def __init__(self, erd_id_list, extract_types):

        self.ERD_ID_list   = erd_id_list
        self.extract_types = extract_types

        self.output_data = {}

    @property
    def UI_data(self):

        UIout = []

        for d in self.output_data:
            tmp_out = {}

            ERD_ID = d
            others = self.output_data[d]

            if not others['excel']: continue

            versions = list(others['excel'].keys())
            lastest_ver = max(versions)

            print("UI lastest version : <{}> for ERD : [{}]".format(lastest_ver, ERD_ID))

            deep_excel = others['excel'][lastest_ver]
            deep_jira  = others['jira'][lastest_ver]

            # excel part : ERD table partition
            tmp_out['erd_id'] = deep_excel['erd_id']
            tmp_out['author'] = deep_excel['author']
            tmp_out['category'] = deep_excel['category']
            tmp_out['product_priority'] = deep_excel['product_priority']
            tmp_out['description'] = deep_excel['description']
            tmp_out['title'] = deep_excel['title']
            tmp_out['version'] = ','.join(versions)

            # jira part : ERD table partition
            tmp_out['HLD'] = deep_jira['HLD']
            tmp_out['l1_jira'] = deep_jira['l1_jira']
            tmp_out['l2_jira'] = deep_jira['l2_jira']
            tmp_out['platform'] = deep_jira['platform']
            tmp_out['status'] = deep_jira['status']
            tmp_out['workload'] = deep_jira['workload']
            if deep_jira['bug_jiras']:
                tmp_out['bug_jiras'] = deep_jira['bug_jiras'].split(',')
            else:
                tmp_out['bug_jiras'] = []

            # jira part : TestCases table partition
            # Now Maybe 'case_age' NOT display
            tmp_out['case_name'] = list(deep_jira['F_casetree'].keys())
            tmp_out['F_report_path'] = []
            for dj in deep_jira['F_casetree']:
                tmp_out['F_report_path'].append(deep_jira['F_casetree'][dj]['F_report_path'])

            UIout.append(tmp_out)
        return UIout



def splitter(action, provider = None, extractor = None):
    """
    action: 'save', 'pick'

    callback: get_cookies > provide cookies
    get_cookies return:  [{'ERD_ID'  : "",'excel' : {}, 'jira' : {}, 'jenkins' : {}, 'UIform' : {}}, ...]

    pick_erd_list: {'erd_list' : [], 'types' : [] }

    Support Types:
    1. Data from/to Excel
    2. Data from/to JIRA Ticket
    3. Data from/to Jenkins
    4. Data from/to UI Form


    """
    types = {'excel'    : ExcelDataProcesser,
             'jira'     : JiraDataProcesser,
             'jenkins'  : JenkinsDataProcesser,
             'UIform'   : UiFormDataProcesser}

    if action == 'save':
        if not provider:
            print("[provider] does NOT exist."); return
        for cookie in provider.formatted_rawdata:
            ERD_ID = cookie.pop('ERD_ID')

            # NOTE: 'excel' type should be processed firstly!!!
            order_list = list(cookie.keys())
            print("\n\n\t[1] ERD: {} , raw list:{}".format(ERD_ID,order_list))
            tail = []
            head = []
            for ol in order_list:
                if ol == 'excel':
                    head.append(ol)
                else:
                    tail.append(ol)
            m_order_list = head + tail
            print("[2] sorted order_list:",m_order_list)

            for tp in m_order_list:
                print("[3] iter tp: [{}]:".format(tp))
                #if tp in types and cookie[tp]:
                if tp in types:
                    print("[4] type match <{}>".format(tp))
                    if cookie[tp]:
                        print("[5] cookie of [{}] does exists!".format(tp))
                        types[tp](ERD_ID, cookies = cookie[tp]).doit(action)

    elif action == 'pick':
        #if not pick_erd_list['erd_list']:
        if not extractor:
            print("[extractor] does NOT exist.");return
        # out_data > eg. {'ERD_ID' : {'excel' : data, 'jira': data, 'jenkins' : data, 'UIform' : data}}
        out_data = {}
        for ERD_ID in extractor.ERD_ID_list:
            extractor.output_data[ERD_ID] = {}
            for tp in extractor.extract_types:
                if tp in types:
                    extractor.output_data[ERD_ID][tp] = types[tp](ERD_ID).doit(action)
        return extractor.output_data
    else:
        print("Action NOT support.")

class CookiesProcesser:

    def save(self):
        assert False, "Children Should implement this method."

    def pick(self):
        assert False, "Children Should implement this method."

    def doit(self):
        assert False, "Children Should implement this method."

    # Extend Common methods
    def get_lastest_ver(self, objs):

        versions = []
        maps = {}

        if not objs: return None

        for o in objs:
            maps[o] = o.version
            versions.append(o.version)

        lastest = max(versions)
        for m in maps:
            if m.version == lastest:
                return m

dynamic_conf_category = {
    'excel' : (
        'erd_id',
        'category',
        'title',
        'description',
        'product_priority',
        'author',
        'version'),

    'jira' : (
        'HLD',
        'status',
        'l1_jira',
        'l2_jira',
        'bug_jiras',
        'platform',
        'workload',

        'F_casetree',
        # F_casetree >> {
        # {
        # 'case_name' : "",
        # 'case_age' : "",
        # 'F_report_path': "",
        # },
        # ... }
    ),

    'jenkins' : (
        'IR_casetree',
        # IR_casetree >> {
        # 'casename' : {
        #    'IR_report_path': "",
        #    'fw_version': "",
        #    'test_result' : "",
        #    'test_log' : "",
        #    'test_date' : "",
        # },
        # 'casename2' : {},
        # ... }
    ),

    'UIform' :(
        'UItest',
    ),
}

from .models_of_rex import Erds,TestCases,TestReports

class ExcelDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['excel']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        """
        auto ignore the data outof 'data_category'.
        """

        except_list = []

        if not self.cookies:
            print("cookies is empty, do nothing.");return

        for c in self.cookies:
            if c not in ExcelDataProcesser.data_category:
                except_list.append(c)

        for e in except_list:
            self.cookies.pop(e)

        # pp(self.cookies)

        el = Erds.objects.filter(erd_id = self.cookies['erd_id'])
        if el:
            for e in el:
                if e.version == self.cookies['version']:
                    print("ERD [{}] version [{}] is already in DB, ignore it.".format(
                        self.cookies['erd_id'],self.cookies['version']))
                    return

        e = Erds(**self.cookies)
        e.save()
        time.sleep(0.1)

    def pick(self):
        """
        """

        el = Erds.objects.filter(erd_id = self.ERD_ID)
        if not el:
            print("The item about your ERD_ID, doesn't exist.")
            return {}

        out = {}
        for e in el:
            out[e.version] = {}
            for d in ExcelDataProcesser.data_category:
                out[e.version][d] = e.__dict__[d]
        return out


    def doit(self,action):
        if action == 'save':
            self.save()
        elif action == 'pick':
            return self.pick()

class JiraDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['jira']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        '''
        auto ignore the data outof 'data_category'.
        '''

        except_list = []

        if not self.cookies:
            print("cookies is empty, do nothing.");return

        for c in self.cookies:
            if c not in JiraDataProcesser.data_category:
                except_list.append(c)

        for e in except_list:
            self.cookies.pop(e)

        # print("\n")
        # pp(self.cookies)
        # print("\n")

        el = Erds.objects.filter(erd_id = self.ERD_ID)

        e = self.get_lastest_ver(el)
        if not e :
            print("ERD_ID [{}] does NOT exist, maybe you should import ERD TABLE items firstly.\n\tel:{}".format(self.ERD_ID,el))
            return

        # Erds Table items save.
        for d in JiraDataProcesser.data_category:
            for c in self.cookies:
                if d in Erds.__dict__ and d == c:
                    e.__dict__[d] = self.cookies[c]
        e.save()
        time.sleep(0.1)

        # TestCases Table items save.
        if 'F_casetree' in  self.cookies and self.cookies['F_casetree']:

            casetree = self.cookies['F_casetree']
            tcl = e.testcases_set.all()

            if not tcl:
                print("> This Erds object [from ERD {}] NOT be related to any case. Attach it. <".format(self.ERD_ID))
                for ct in casetree:
                    e.testcases_set.create(**ct).save()
                    time.sleep(0.1)
            else:
                for ct in casetree:
                    if ct['case_name'] not in [tc.case_name for tc in tcl]:
                        print("> new case [{}] bound to Erds Table. <".format(ct['case_name']))
                        e.testcases_set.create(**ct).save()
                        time.sleep(0.1)
                    else:

                        s1 = set(ct['F_report_path'].split(','))

                        # Should only!
                        tc = e.testcases_set.get(case_name = ct['case_name'])

                        print("\t S1 : {},\n\t S2 : {}\n\t S1-S2 : {} ".
                              format(s1,
                                     set(tc.F_report_path.split(',')),
                                     s1 - set(tc.F_report_path.split(','))))

                        if tc and s1 - set(tc.F_report_path.split(',')):
                            for s in (s1 -set(tc.F_report_path.split(','))):
                                print("> report added: [{}] <".format(s))
                                tc.F_report_path += str(s)
                                tc.save()
                                time.sleep(0.1)
                        else:
                            print("> case name and report part already exist, do nothing <")
        else:
            print("F_case_tree NOT be provided, do nothing for TESTCASES Table items")

    def pick(self):

        el = Erds.objects.filter(erd_id = self.ERD_ID)
        out = {}

        if not el:
            print("> ERD ID [{}] is NOT in DB.<".format(self.ERD_ID))
            return out

        for e in el:
            out[e.version] = {}

            print("\n\tERD_ID : {}, Version : {}".format(self.ERD_ID, e.version))
            for d in JiraDataProcesser.data_category:
                # pick Erds Table items
                if d in Erds.__dict__:
                    print(">> [pick] Deal Erds Table's type [{}]".format(d))
                    out[e.version][d] = e.__dict__[d]

                # pick TestCases Table items
                if d == 'F_casetree':
                    print(">> [pick] Deal TestCases Table's type [{}]".format(d))
                    tcl = e.testcases_set.all()
                    out[e.version]['F_casetree'] ={}
                    for tc in tcl:
                        out[e.version]['F_casetree'].update(
                            {tc.case_name : {
                                'case_name' : tc.case_name,
                                'case_age'  : tc.case_age,
                                'F_report_path' :tc.F_report_path,
                            }})
        return out

    def doit(self,action):
        if action == 'save':
            mutex.acquire()
            self.save()
            mutex.release()
        elif action == 'pick':
            return self.pick()

class JenkinsDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['jenkins']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        '''
        auto ignore the data outof 'data_category'.
        '''
        except_list = []

        if not self.cookies:
            print("cookies is empty, do nothing.");return

        for c in self.cookies:
            if c not in JenkinsDataProcesser.data_category:
                except_list.append(c)

        for e in except_list:
            self.cookies.pop(e)

        e = Erds(**self.cookies)

    def pick(self):
        pass

    def doit(self,action):
        if action == 'save':
            mutex.acquire()
            self.save()
            mutex.release()
        elif action == 'pick':
            return self.pick()

class UiFormDataProcesser(CookiesProcesser):

    data_category = dynamic_conf_category['UIform']

    def __init__(self, ERD_ID, cookies = {}, ERD_model = Erds):
        self.ERD_ID = ERD_ID
        self.cookies = cookies
        self.ERD_model = ERD_model

    def save(self):
        pass

    def pick(self):
        pass

    def doit(self,action):
        if action == 'save':
            self.save()
        elif action == 'pick':
            return self.pick()


