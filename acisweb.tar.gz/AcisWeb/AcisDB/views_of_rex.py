#! /usr/bin/env python3
# coding=utf-8

"""
< For Rex Debug >
"""

from django.shortcuts import render,render_to_response
from django.http import HttpResponse,HttpResponseRedirect

import json,time,threading,copy
from pprint import pprint as pp, pformat

from . import log
from . import vcore

import logging
mlogger = logging.getLogger(__name__).info


class ExcelProvider(vcore.Provider):

    def get_data(self):
        from .test_cookies_of_rex import test_get_excel_data
        logger_to_excel = logging.getLogger(__name__ + '.from_excel')
        t = test_get_excel_data()
        logger_to_excel.info(pformat(t))
        return t

    @property
    def formatted_rawdata(self):
        """
        For Excel Data:
        >>> [
        >>> ...
        >>> {
        >>>   "PLATFORM" : "",
        >>>   "ERD_ID" : "",
        >>>   "excel" : {
        >>>     'erd_id' : "",
        >>>     'category' : "",
        >>>     'title' : "",
        >>>     'description' : "",
        >>>     'product_priority' : "",
        >>>     'author' : "",
        >>>     'version' : "",
        >>>     'platform' : "",
        >>> } ...
        >>> ]
        """
        return self.get_data()

class JiraProvider(vcore.Provider):

    def get_data(self):
        from .test_cookies_of_rex import test_get_jira_data
        logger_to_jira = logging.getLogger(__name__ + '.from_jira')
        t = test_get_jira_data()
        logger_to_jira.info(pformat(t))
        return t

    @property
    def formatted_rawdata(self):
        """
        For JIRA Ticket Data:
        >>> [
        >>> ...
        >>> {
        >>>   "PLATFORM" : "",
        >>>   "ERD_ID" : "",
        >>>   "excel" : {
        >>>     'HLD' : "",
        >>>     'status' : "",
        >>>     'l1_jira' : "",
        >>>     'l2_jira' : "",
        >>>     'bug_jiras' : "",
        >>>     'platform' : "",
        >>>     'workload' : "",

        >>>     'F_casetree' : {
        >>>                 ...
        >>>                 {
        >>>                     'case_name' : "",
        >>>                     'case_age' : "",
        >>>                     'F_report_path': "",
        >>>                 },
        >>>                 ... }
        >>>     }
        >>> ...
        >>> ]
        """
        return self.get_data()

class JenkinsProvider(vcore.Provider):

    def get_data(self):
        from .test_cookies_of_rex import test_get_jenkins_data
        logger_to_jenkins = logging.getLogger(__name__ + '.from_jenkins')
        t = test_get_jenkins_data()
        logger_to_jenkins.info(pformat(t))
        return t

    @property
    def formatted_rawdata(self):
        """
        NOTE: For jenkins data, ONLY one element for list.

        >>> [{
        >>>     "PLATFORM" : "",

        >>>     'ACIS_A_S_Test_Temp_Volt' : {
        >>>         'fw_version' : "",
        >>>         'test_result' : "",
        >>>         'test_log' : "",
        >>>         'test_date' : "",
        >>>         'IR_report_path' : "",
        >>>         },
        >>>     'ACIS_A_S_Test_Temp_ssss' : {
        >>>         'fw_version' : "",
        >>>         'test_result' : "",
        >>>         'test_log' : "",
        >>>         'test_date' : "",
        >>>         'IR_report_path' : "",
        >>>     },
        >>>     'ACIS_A_S_Test_Temp_abcd' : {
        >>>         'fw_version' : "",
        >>>         'test_result' : "",
        >>>         'test_log' : "",
        >>>         'test_date' : "",
        >>>         'IR_report_path' : "",
        >>>     },
        >>>     ... ...
        >>> }]
        """
        return self.get_data()

class SubProvider(vcore.Provider):

    @property
    def formatted_rawdata(self):
        from .test_cookies_of_rex import random_gen_cookies
        return random_gen_cookies()


class RealExtractor(vcore.Extractor):

    @property
    def UI_data(self):

        UIout = []

        self.PLATFORM_LIST

        data = self._get_data().pop(self.PLATFORM_LIST[0])

        # for d in self._get_data():
        for d in data:
            tmp_out = {}

            ERD_ID = d
            others = data[d]

            if not others['excel']: continue

            versions = list(others['excel'].keys())
            lastest_ver = max(versions)

            print("UI lastest version : <{}> for ERD : [{}]".format(lastest_ver, ERD_ID))

            deep_excel = others['excel'][lastest_ver]
            deep_jira  = others['jira'][lastest_ver]

            # excel part : ERD table partition
            tmp_out['erd_id'] = deep_excel['erd_id']
            tmp_out['platform'] = deep_excel['platform']
            tmp_out['author'] = deep_excel['author']
            tmp_out['category'] = deep_excel['category']
            tmp_out['product_priority'] = deep_excel['product_priority']
            tmp_out['description'] = deep_excel['description']
            tmp_out['title'] = deep_excel['title']
            tmp_out['version'] = ','.join(versions)

            # jira part : ERD table partition
            tmp_out['HLD'] = deep_jira['HLD']
            tmp_out['l1_jira'] = deep_jira['l1_jira']
            tmp_out['l2_jira'] = deep_jira['l2_jira']
            #tmp_out['platform'] = deep_jira['platform']
            tmp_out['status'] = deep_jira['status']
            tmp_out['workload'] = deep_jira['workload']
            if deep_jira['bug_jiras']:
                tmp_out['bug_jiras'] = deep_jira['bug_jiras'].split(',')
            else:
                tmp_out['bug_jiras'] = []

            # jira part : TestCases table partition
            # Now Maybe 'case_age' NOT display
            tmp_out['case_name'] = list(deep_jira['F_casetree'].keys())
            tmp_out['F_report_path'] = []
            for dj in deep_jira['F_casetree']:
                tmp_out['F_report_path'].append(deep_jira['F_casetree'][dj]['F_report_path'])

            UIout.append(tmp_out)
        #pp(UIout)
        return UIout


def rex_jump(request):

    # ep = ExcelProvider()
    # jip = JiraProvider().formatted_rawdata
    # jkp = JenkinsProvider().formatted_rawdata

    re = RealExtractor(['SD55'])
    vcore.splitter('pick_all', extractor = re )

    mlogger(pformat(re.output_data))
    #assert False

    return render(request, 'LigerUI/ACIS/rex_test_page.htm', {'cookies' : json.dumps(re.UI_data)})
